# Assignment 1 — CS23BTECH11024 (Sai Rishi Kasturi)

## Folder Structure

```
ASSGN_1/
├── README.md                    ← This file
│
├── Q1/
│   ├── cosine.ipynb             ← Cosine implementation
│   └── xor.ipynb                ← XOR implementation
│
├── Q2/
│   └── Q2.pdf                   ← Universal Approximation Theorem (written solution)
│
├── Q3/
│   └── Q3.pdf                   ← Backpropagation with Softmax/Hinge Loss (written solution)
│
├── Q4/
│   ├── data_gen.ipynb           ← Dataset generation code
│   ├── dataset_description.pdf  ← Dataset description document
│   ├── iith_mess_500.csv        ← Generated dataset (500 samples)
│   └── iith_mess_5000.csv       ← Generated dataset (5000 samples)
│
├── Q5/
│   ├── 5c.png                   ← Plot: ADALINE Learning Rate Sensitivity
│   ├── 5d.png                   ← Plot: ADALINE MSE vs Training Set Size
│   ├── q5_adaline.ipynb         ← ADALINE implementation and experiments
│   └── Q5.pdf                   ← ADALINE theory (written solution)
│
├── Q6/
│   ├── iith_mess_5000.csv       ← Dataset used for Q6
│   ├── Q6_final.ipynb           ← Neural network implementation notebook
│   └── Q6.pdf                   ← Vanishing gradient / dropout theory (written solution)
│
└── Q7/
    └── Q7.pdf                   ← Kernel methods & neural feature representation (written solution)
```

---

## How to Run the Code

### Prerequisites

```bash
pip install numpy pandas matplotlib scikit-learn jupyter
```

---

### Q4 — Dataset Generation

Running all cells will regenerate:
- `iith_mess_500.csv` — base dataset (500 samples)
- `iith_mess_5000.csv` — extended dataset (5000 samples)


---

### Q5 — ADALINE

Running all cells will:
- Train ADALINE on the mess dataset
- Reproduce the learning rate sensitivity plot (`5c.png`)
- Reproduce the MSE vs training set size plot (`5d.png`)

---

### Q6 — Neural Network

This notebook requires `iith_mess_5000.csv` (already present in the `Q6/` folder).

---